export class Projects {
      'sno':number;
      'amtpledged':number;
      'blurb':string;  
      'by':string;
      'country':string;
      'currency':string;
      'endtime':string;
      'location':string;
      'percentagefunded':number;
      'numbackers':string;
      'state':string;
      'title':string;
      'type':string;
      'url':string;
}